package com.example.unde_data_recorder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
